package org.domain.config;

public class CorsConfig {
}