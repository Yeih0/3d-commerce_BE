package org.domain.config;

public class JwtConfig {
}